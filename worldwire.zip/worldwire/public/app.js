const REGION_LABELS = {
  world: 'World',
  americas: 'Americas',
  europe: 'Europe',
  asia: 'Asia',
  middle_east: 'Middle East',
  africa: 'Africa',
  oceania: 'Oceania',
};

const REFRESH_MS = 3 * 60 * 1000; // 3 minutes
let currentRegion = 'world';
let refreshTimer = null;

// Mirrors the REGIONS map in server.js. Kept here too so the map can
// project markers and know which region a country belongs to without
// an extra round trip.
const COUNTRY_COORDS = [
  { code: 'us', name: 'United States', lat: 38.9, lon: -77.0, region: 'americas' },
  { code: 'ca', name: 'Canada', lat: 45.4, lon: -75.7, region: 'americas' },
  { code: 'mx', name: 'Mexico', lat: 19.4, lon: -99.1, region: 'americas' },
  { code: 'br', name: 'Brazil', lat: -15.8, lon: -47.9, region: 'americas' },
  { code: 'ar', name: 'Argentina', lat: -34.6, lon: -58.4, region: 'americas' },
  { code: 'gb', name: 'United Kingdom', lat: 51.5, lon: -0.1, region: 'europe' },
  { code: 'fr', name: 'France', lat: 48.9, lon: 2.3, region: 'europe' },
  { code: 'de', name: 'Germany', lat: 52.5, lon: 13.4, region: 'europe' },
  { code: 'ua', name: 'Ukraine', lat: 50.4, lon: 30.5, region: 'europe' },
  { code: 'pl', name: 'Poland', lat: 52.2, lon: 21.0, region: 'europe' },
  { code: 'cn', name: 'China', lat: 39.9, lon: 116.4, region: 'asia' },
  { code: 'in', name: 'India', lat: 28.6, lon: 77.2, region: 'asia' },
  { code: 'jp', name: 'Japan', lat: 35.7, lon: 139.7, region: 'asia' },
  { code: 'kr', name: 'South Korea', lat: 37.6, lon: 127.0, region: 'asia' },
  { code: 'id', name: 'Indonesia', lat: -6.2, lon: 106.8, region: 'asia' },
  { code: 'il', name: 'Israel', lat: 31.8, lon: 35.2, region: 'middle_east' },
  { code: 'sa', name: 'Saudi Arabia', lat: 24.7, lon: 46.7, region: 'middle_east' },
  { code: 'tr', name: 'Turkey', lat: 39.9, lon: 32.9, region: 'middle_east' },
  { code: 'ir', name: 'Iran', lat: 35.7, lon: 51.4, region: 'middle_east' },
  { code: 'eg', name: 'Egypt', lat: 30.0, lon: 31.2, region: 'middle_east' },
  { code: 'ng', name: 'Nigeria', lat: 9.1, lon: 7.4, region: 'africa' },
  { code: 'za', name: 'South Africa', lat: -25.7, lon: 28.2, region: 'africa' },
  { code: 'ke', name: 'Kenya', lat: -1.3, lon: 36.8, region: 'africa' },
  { code: 'et', name: 'Ethiopia', lat: 9.0, lon: 38.7, region: 'africa' },
  { code: 'au', name: 'Australia', lat: -35.3, lon: 149.1, region: 'oceania' },
  { code: 'nz', name: 'New Zealand', lat: -41.3, lon: 174.8, region: 'oceania' },
];

const CONTINENT_LABELS = [
  { text: 'NORTH AMERICA', lat: 48, lon: -100 },
  { text: 'SOUTH AMERICA', lat: -18, lon: -60 },
  { text: 'EUROPE', lat: 54, lon: 15 },
  { text: 'AFRICA', lat: 2, lon: 20 },
  { text: 'ASIA', lat: 48, lon: 90 },
  { text: 'MIDDLE EAST', lat: 26, lon: 45 },
  { text: 'OCEANIA', lat: -28, lon: 140 },
];

let mapCountryCounts = {};

const grid = document.getElementById('dispatchGrid');
const regionBar = document.getElementById('regionBar');
const tickerTrack = document.getElementById('tickerTrack');
const statusDot = document.getElementById('statusDot');
const lastUpdateEl = document.getElementById('lastUpdate');
const clockEl = document.getElementById('utcClock');

// Simple equirectangular projection onto our 1000x500 viewBox.
function project(lat, lon) {
  const x = (lon + 180) * (1000 / 360);
  const y = (90 - lat) * (500 / 180);
  return { x, y };
}

function svgEl(tag, attrs) {
  const el = document.createElementNS('http://www.w3.org/2000/svg', tag);
  Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, v));
  return el;
}

function buildMapSkeleton() {
  const svg = document.getElementById('worldMap');
  svg.innerHTML = '';

  // Graticule: a line every 30 degrees of longitude/latitude.
  for (let lon = -180; lon <= 180; lon += 30) {
    const { x } = project(0, lon);
    const cls = lon === 0 ? 'map-graticule-line meridian' : 'map-graticule-line';
    svg.appendChild(svgEl('line', { x1: x, y1: 0, x2: x, y2: 500, class: cls }));
  }
  for (let lat = -90; lat <= 90; lat += 30) {
    const { y } = project(lat, 0);
    const cls = lat === 0 ? 'map-graticule-line equator' : 'map-graticule-line';
    svg.appendChild(svgEl('line', { x1: 0, y1: y, x2: 1000, y2: y, class: cls }));
  }

  // Rough continent labels for orientation (this is a schematic signal
  // board, not a geographically precise map).
  CONTINENT_LABELS.forEach((c) => {
    const { x, y } = project(c.lat, c.lon);
    const label = svgEl('text', { x, y, class: 'map-continent-label', 'text-anchor': 'middle' });
    label.textContent = c.text;
    svg.appendChild(label);
  });

  // One marker group per tracked country, built once; later refreshes
  // only update size/color, not the DOM structure.
  COUNTRY_COORDS.forEach((c) => {
    const { x, y } = project(c.lat, c.lon);
    const group = svgEl('g', { 'data-code': c.code, 'data-region': c.region });

    const pulse = svgEl('circle', { cx: x, cy: y, r: 4, class: 'map-pulse' });
    const dot = svgEl('circle', { cx: x, cy: y, r: 3.5, class: 'map-dot' });

    group.appendChild(pulse);
    group.appendChild(dot);
    group.style.cursor = 'pointer';

    group.addEventListener('click', () => {
      if (c.region === currentRegion) return;
      currentRegion = c.region;
      renderRegionBar();
      loadHeadlines();
    });
    group.addEventListener('mouseenter', (e) => showMapTooltip(c, e));
    group.addEventListener('mousemove', (e) => showMapTooltip(c, e));
    group.addEventListener('mouseleave', hideMapTooltip);

    svg.appendChild(group);
  });
}

function showMapTooltip(country, evt) {
  const tooltip = document.getElementById('mapTooltip');
  const frame = document.querySelector('.map-frame');
  const count = mapCountryCounts[country.code] || 0;
  tooltip.innerHTML = `${country.name.toUpperCase()} <span class="count">${count} dispatch${count === 1 ? '' : 'es'}</span>`;
  const rect = frame.getBoundingClientRect();
  tooltip.style.left = `${evt.clientX - rect.left}px`;
  tooltip.style.top = `${evt.clientY - rect.top}px`;
  tooltip.hidden = false;
}

function hideMapTooltip() {
  document.getElementById('mapTooltip').hidden = true;
}

function updateMapMarkers() {
  const svg = document.getElementById('worldMap');
  const maxCount = Math.max(1, ...Object.values(mapCountryCounts));

  COUNTRY_COORDS.forEach((c) => {
    const group = svg.querySelector(`g[data-code="${c.code}"]`);
    if (!group) return;
    const dot = group.querySelector('.map-dot');
    const pulse = group.querySelector('.map-pulse');
    const count = mapCountryCounts[c.code] || 0;
    const hasActivity = count > 0;
    const isActiveRegion = c.region === currentRegion || currentRegion === 'world';

    const radius = hasActivity ? 3.5 + (count / maxCount) * 7 : 3;
    dot.setAttribute('r', radius.toFixed(1));
    dot.classList.toggle('has-activity', hasActivity);
    dot.classList.toggle('in-active-region', hasActivity && c.region === currentRegion && currentRegion !== 'world');
    pulse.classList.toggle('active', hasActivity && isActiveRegion);
  });
}

async function loadMapData() {
  try {
    const res = await fetch('/api/headlines?region=world');
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');

    mapCountryCounts = {};
    (data.articles || []).forEach((a) => {
      const code = (a.country || '').toLowerCase();
      if (!code) return;
      mapCountryCounts[code] = (mapCountryCounts[code] || 0) + 1;
    });
    updateMapMarkers();
  } catch (err) {
    // Map is a secondary view; fail quietly and leave dots at rest state.
    console.warn('Map data unavailable:', err.message);
  }
}

function renderRegionBar() {
  regionBar.innerHTML = '';
  Object.entries(REGION_LABELS).forEach(([key, label]) => {
    const btn = document.createElement('button');
    btn.className = 'region-chip' + (key === currentRegion ? ' active' : '');
    btn.textContent = label;
    btn.addEventListener('click', () => {
      if (key === currentRegion) return;
      currentRegion = key;
      renderRegionBar();
      loadHeadlines();
    });
    regionBar.appendChild(btn);
  });
}

function timeAgo(iso) {
  if (!iso) return 'time unknown';
  const then = new Date(iso.replace(' ', 'T') + (iso.includes('Z') ? '' : 'Z'));
  const diffMin = Math.round((Date.now() - then.getTime()) / 60000);
  if (diffMin < 1) return 'moments ago';
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.round(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return `${Math.round(diffHr / 24)}d ago`;
}

function renderCards(articles) {
  grid.innerHTML = '';
  if (!articles.length) {
    grid.innerHTML = '<div class="state-message">NO DISPATCHES RETURNED FOR THIS REGION</div>';
    return;
  }
  articles.forEach((a) => {
    const card = document.createElement('div');
    card.className = 'dispatch-card';
    card.innerHTML = `
      <div class="dateline">${(a.country || 'world').toUpperCase()} — ${timeAgo(a.publishedAt)}</div>
      <a class="headline" href="${a.url}" target="_blank" rel="noopener noreferrer">${escapeHtml(a.title)}</a>
      <div class="dek">${escapeHtml(a.description || '').slice(0, 160)}</div>
      <div class="byline">${escapeHtml(a.source)}</div>
    `;
    grid.appendChild(card);
  });
}

function renderTicker(articles) {
  if (!articles.length) return;
  tickerTrack.innerHTML = articles
    .slice(0, 12)
    .map((a) => `<span class="ticker-item">${escapeHtml(a.title)}</span>`)
    .join('');
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

async function loadHeadlines() {
  grid.innerHTML = '<div class="state-message">PULLING LATEST DISPATCHES…</div>';
  try {
    const res = await fetch(`/api/headlines?region=${encodeURIComponent(currentRegion)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');

    renderCards(data.articles);
    renderTicker(data.articles);
    updateMapMarkers();
    statusDot.classList.add('live');
    lastUpdateEl.textContent = `updated ${new Date().toLocaleTimeString('en-US', { hour12: false })} local`;
  } catch (err) {
    grid.innerHTML = `<div class="state-message error">SIGNAL LOST — ${escapeHtml(err.message)}</div>`;
    statusDot.classList.remove('live');
    lastUpdateEl.textContent = 'connection error';
  }
}

function tickClock() {
  const now = new Date();
  clockEl.textContent = now.toISOString().slice(11, 19) + ' UTC';
}

function startPolling() {
  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(() => {
    loadHeadlines();
    loadMapData();
  }, REFRESH_MS);
}

buildMapSkeleton();
renderRegionBar();
loadHeadlines();
loadMapData();
startPolling();
tickClock();
setInterval(tickClock, 1000);
