// providers/newsdata.js
// Thin adapter around the NewsData.io "latest" endpoint. Keeping all
// provider-specific parsing here means you can add another provider
// (GNews, Mediastack, etc.) later by writing one more file with the
// same exported shape: fetchHeadlines({ countries, category }) -> normalized articles.

const fetch = require('node-fetch');

const BASE_URL = 'https://newsdata.io/api/1/latest';

// NewsData.io normalizes each article roughly to this shape. We map it
// down to a smaller, stable shape so the frontend never has to know
// which provider produced the data.
function normalize(article) {
  return {
    id: article.article_id || article.link,
    title: article.title || 'Untitled dispatch',
    description: article.description || '',
    url: article.link,
    source: article.source_id || article.source_name || 'unknown source',
    country: (article.country && article.country[0]) || 'world',
    publishedAt: article.pubDate || null,
    image: article.image_url || null,
  };
}

/**
 * @param {object} opts
 * @param {string[]} opts.countries - ISO country codes, max 5 per NewsData free/basic plans
 * @param {string} [opts.category] - e.g. "politics", "world"
 * @param {string} [opts.language]
 */
async function fetchHeadlines({ countries = [], category = 'politics', language = 'en' }) {
  const apiKey = process.env.NEWSDATA_API_KEY;
  if (!apiKey) {
    throw new Error('NEWSDATA_API_KEY is not set. Copy .env.example to .env and add your key.');
  }

  const params = new URLSearchParams({
    apikey: apiKey,
    category,
    language,
  });
  if (countries.length) {
    // NewsData allows up to 5 country codes per request on free/basic plans.
    params.set('country', countries.slice(0, 5).join(','));
  }

  const res = await fetch(`${BASE_URL}?${params.toString()}`);
  const body = await res.json().catch(() => null);

  if (!res.ok || !body) {
    const message = body && body.results ? JSON.stringify(body.results) : `HTTP ${res.status}`;
    throw new Error(`NewsData.io request failed: ${message}`);
  }
  if (body.status !== 'success') {
    throw new Error(`NewsData.io returned an error: ${JSON.stringify(body)}`);
  }

  return (body.results || []).map(normalize);
}

module.exports = { fetchHeadlines };
